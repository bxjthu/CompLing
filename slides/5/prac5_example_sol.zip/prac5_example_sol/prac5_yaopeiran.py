"""
    CompLing - Prac 5
    Peiran YAO 2015011315
"""
import re

# (1)
# read in the messed file.
with open('Lovers_on_Aran_messed.txt') as f:
    lines = f.readlines()

# step 1: find all words and punctuations, join them with a single space
lines = map(lambda x: ' '.join(re.findall(r"\w+|[^\s]+", x)), lines)
# step 2: filter out empty lines
lines = filter(lambda x: len(x) > 0, lines)

# write out result
with open('Lovers_on_Aran.txt', 'w') as f:
    for line in lines:
        f.write(line)
        f.write('\n')

# (2)
# read in the cleaned file
with open('Lovers_on_Aran.txt') as f:
    lines = f.readlines()
words = []
for line in lines:
    words += line[:-1].split()

# count words
count = len(words)

# find target word
target_words = filter(lambda x: ('A' <= x[0] <= 'Z') or len(x) < 3, words)

with open('count_and_find.txt', 'w') as of:
    of.write(str(count))
    of.write('\n')
    for w in target_words:
        of.write(w)
        of.write('\n')

# (3)
from collections import Counter

def tokenize(raw_sentence):
    # ^ : start of string; $: end of string
    return ['^-2', '^-1'] + raw_sentence.lower().split() + ['$1', '$2']

def build_model(sentences):
    # use collections.Counter to calculate one gram count.
    one_grams = Counter()
    for sent in sentences:
        one_grams.update(sent)

    bigrams = []
    for sent in sentences:
        for bigram in zip(sent, sent[1:]): # use zip() to generate bigrams
            bigrams.append(bigram)
    bigram_count = Counter(bigrams)
    bigram_probs = {}
    for bigram in bigrams:
        # marginal probability
        bigram_probs[bigram] = bigram_count[bigram] / one_grams[bigram[0]]

    # same as bigram
    trigrams = []
    for sent in sentences:
        for trigram in zip(sent, sent[1:], sent[2:]):
            trigrams.append(trigram)
    trigram_count = Counter(trigrams)
    trigram_probs = {}
    for trigram in trigrams:
        trigram_probs[trigram] = trigram_count[trigram] / bigram_count[(trigram[0], trigram[1])]
    
    return bigram_probs, trigram_probs

def calc_prob(bigram_probs, trigram_probs, sent):
    p = bigram_probs[tuple(sent[:2])]
    for trigram in zip(sent[2:], sent[3:], sent[4:]):
        p *= trigram_probs[trigram]
    return p

with open('Lovers_on_Aran.txt') as f:
    lines = f.readlines()
sents = [tokenize(l) for l in lines]
bigram_probs, trigram_probs = build_model(sents)

line_probs = []
for i, sent in enumerate(sents): # use enumerate to both index and line
    p = calc_prob(bigram_probs, trigram_probs, sent)
    line_probs.append((i, p))
line_probs.sort(key=lambda x: x[1], reverse=True)

with open('trigram_prob.txt', 'w') as f:
    for i, p in line_probs:
        f.write("{}: {:.3f}\n".format(i, p))