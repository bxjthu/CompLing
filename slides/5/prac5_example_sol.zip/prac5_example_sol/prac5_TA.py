import re
import operator
from math import log, exp

################# Question 1 #################
# note that we can do without nltk.word_tokenize in this question
inf = open('Lovers_on_Aran_messed.txt', 'r')
ouf = open('Lovers_on_Aran.txt', 'w')
for line in inf:
	if not re.match(pattern='^\s+$', string=line): # retain only non-empty lines
		line = re.sub('\s+', ' ', line) # replace succesive spaces with 1 space
		line = re.sub('\s*(?P<punc>[!\?\.,])\s*', ' \g<punc> ', line) # add spaces around punctuations
		ouf.write(line.strip()+'\n')
inf.close()
ouf.close()

################# Question 2 #################
inf = open('Lovers_on_Aran.txt', 'r')
ouf = open('count_and_find.txt', 'w')
count = 0
tgt_words = [] # target words
for line in inf:
	for w in line.split():
		count += 1
		if re.match(r'[A-Z]', w) or len(w) < 3:
			tgt_words.append(w)
ouf.write(str(count)+'\n')
for w in tgt_words:
	ouf.write(w+'\n')
inf.close()
ouf.close()

################# Question 3 #################
inf = open('Lovers_on_Aran.txt', 'r')
ouf = open('trigram_prob.txt', 'w')
sents = []
for line in inf:
	padded_sent = '<s> ' * 2 + line + ' <\s>' * 2
	split_sent = padded_sent.lower().split()
	sents.append(split_sent)

tri_dict = {} # a dict of trigram probs, with structure: {'w1w2':{'w3':prob, ...}, ...}
for sent in sents:
	for i in range(0, len(sent) - 2):
		w1w2 = sent[i] + ' ' + sent[i+1]
		if w1w2 not in tri_dict:
			tri_dict[w1w2] = {}
		w3 = sent[i+2]
		if w3 not in tri_dict[w1w2]:
			tri_dict[w1w2][w3] = 0
		tri_dict[w1w2][w3] += 1
tri_dict = {w1w2: {w3: count / sum(tri_dict[w1w2].values()) for w3, count in tri_dict[w1w2].items()} for w1w2 in tri_dict}

sent_prob = {} # a dict of sentence probabilities, with structure: {lineID:prob, ...}
for i, sent in enumerate(sents):
	sent_prob[i] = round(exp(sum([log(tri_dict[sent[j]+' '+sent[j+1]][sent[j+2]]) for j in range(0, len(sent) - 2)])), 3) # use log probs
sorted_sent_prob = sorted(sent_prob.items(), key=operator.itemgetter(1), reverse=True)
for id, prob in sorted_sent_prob:
	ouf.write('{}: {}\n'.format(id, prob))
inf.close()
ouf.close()