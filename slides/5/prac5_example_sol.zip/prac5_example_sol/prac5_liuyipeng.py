#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
Author: Yipeng Liu
Email: liuyp18@mail.tsinghua.edu.cn
'''

'''
Part I: Cleaning text
'''

from nltk import word_tokenize

# read file
with open('Lovers_on_Aran_messed.txt', 'r') as f:
	text = f.read()
	f.close()

# process text
text = text.replace('\t', '')
sentenses = [' '.join(word_tokenize(sentense)) for sentense in text.split('\n') if set(sentense) not in [set(' '), set()]] # first tokenize words, them join them into sentenses

# write file
with open('Lovers_on_Aran.txt', 'w', newline = '\n') as f: # newline = UNIX: '\n' / Windows: '\r\n'
	for sentense in sentenses:
		f.writelines('%s\n' % sentense)
	f.close()

'''
Part II: Word counting and matching
'''

import string

# read file
with open('Lovers_on_Aran.txt', 'r') as f:
	text = f.read()
	f.close()

# get words
words = text.replace('\n', ' ')[:-1].split(' ') # remove '\n' in the last line.

# count words
count = len(words)

# find certain words
worded = [word for word in words if (word[0] in string.ascii_uppercase) or (len(word) < 3)]

# write file
with open('count_and_find.txt', 'w', newline = '\n') as f:
    f.write('%d\n' % count)
    for word in worded:
        f.writelines('%s\n' % word)
    f.close()

'''
Part III: Calculating trigram probability
'''

# read file
with open('Lovers_on_Aran.txt', 'r') as f:
	text = f.read()
	f.close()

# process sentenses

# calculate word count
# data structure: dict[w_n-w w_n-1][w_n]
sentenses = ['^ ^ %s $ $' % sentense for sentense in text.lower().split('\n')[:-1]] # remove '\n' in the last line.
trigram = {}
for sentense in sentenses:
	words = sentense.split(' ')
	for i in range(len(words) - 2):
		word = words[i + 2]
		before = ' '.join(words[i : i + 2])
		if before in trigram.keys():
			if word in trigram[before].keys():
				trigram[before][word] += 1
			else:
				trigram[before][word] = 1
		else:
			trigram[before] = {}
			trigram[before][word] = 1

# generate trigram
for before in trigram:
	total = sum(trigram[before].values())
	for word in trigram[before]:
		trigram[before][word] /= total

# calculate probability of each sentense
probabilities = []
for sentense in sentenses:
	probability = 1
	words = sentense.split(' ')
	for i in range(len(words) - 2):
		word = words[i + 2]
		before = ' '.join(words[i : i + 2])
		probability *= trigram[before][word]
	probabilities.append(round(probability, 3))

# sort probabilities
from operator import itemgetter
probabilities = sorted(zip(probabilities, range(len(probabilities))), key = itemgetter(0), reverse = True)

# write file
with open('trigram_prob.txt', 'w', newline = '\n') as f:
	for probability in probabilities:
		f.writelines('%d: %.3f\n' % probability[::-1]) # [::-1] reverse the tuple
	f.close()