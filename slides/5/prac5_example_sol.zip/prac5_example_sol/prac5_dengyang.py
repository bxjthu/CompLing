from nltk import word_tokenize
import re
from decimal import Decimal
import operator

text = open('practical_5.txt', 'r')
final_text = open('Lovers_on_Aran.txt', 'w')

for line in text:
    if line.strip():
        tokens = word_tokenize(line)
        final_line = " ".join(tokens) + '\n'
        final_text.write(final_line)

final_text.close()
# Task(1) finished

file = open('Lovers_on_Aran.txt', 'r')
task_2 = open('count_and_find.txt', 'w')

words = []
sents = []

for line in file:
    tokens = word_tokenize(line)
    for t in tokens:
        words.append(t)
    padded_sent = '<s> ' * 2 + line + ' <\s>' * 2
    split_sent = padded_sent.lower().split()
    sents.append(split_sent)

task_2.write(str(len(words)) + '\n')
for w in words:
    if re.search(r'^[A-Z]|^\S{,2}$', w):
        task_2.write(w + '\n')
# Task(2) finished

tri_probs = open('trigram_prob.txt', 'w')
tri_dict = {}

for sent in sents:
    for i in range(len(sent)-3):
        trigram = sent[i] + ' ' + sent[i+1]
        if trigram not in tri_dict:
            tri_dict[trigram] = {}
        if sent[i+2] not in tri_dict[trigram]:
            tri_dict[trigram][sent[i+2]] = 0
        tri_dict[trigram][sent[i+2]] += 1

tri_dict = {tri: {w3: count/sum(tri_dict[tri].values()) for w3, count in tri_dict[tri].items()} for tri in tri_dict.keys()}

sent_probs = {}

for sent in sents:
    sentence = sents.index(sent)
    for i in range(len(sent)-3):
        tri = sent[i] + " " + sent[i+1]
        word_prob = tri_dict[tri][sent[i+2]]
        if sentence not in sent_probs:
            sent_probs[sentence] = 1
        sent_probs[sentence] *= word_prob

sorted_by_keys = sorted(sent_probs.items(), key=operator.itemgetter(0))
sorted_probs = sorted(sorted_by_keys, key=operator.itemgetter(1), reverse=True)

for sent_prob in sorted_probs:
    output = str(sent_prob[0]) + ': ' + str(Decimal(sent_prob[1]).quantize(Decimal('0.000'))) + '\n'
    tri_probs.write(output)
# Task(3) finished
