################################################################
# Practice 3.1.a

words = ['is', 'NLP', 'fun', '?']

tmp = words[0]
words[0] = words[1]
words[1] = tmp
words[3] = '!'

print (words)

################################################################
# Practice 3.1.b

sentence = ''.join([' '.join(words[:3]), words[3]])

print (sentence)


################################################################
# Practice 3.2.a

# import the tokenizor
from nltk.tokenize import word_tokenize

# define some file paths + names
file = '/Users/yeyuxiao/Intern/Tsinghua/Computational_Linguistics' \
       '/Week3/Lovers_on_Aran_messed.txt'
new_file = '/Users/yeyuxiao/Intern/Tsinghua/Computational_Linguistics' \
       '/Week3/Lovers_on_Aran.txt'

# load the file + create the new file
with open(file, 'r') as f, open(new_file, 'w') as nf:
    for line in f:
        # remove empty lines
        if line.strip():
            # get word/punctuation tokens
            tokens = word_tokenize(line)
            # join tokens with a space
            new_line = ' '.join(tokens)
            # write to the new file
            print (new_line, file=nf)

################################################################
# Practice 3.2.b

# import some modules
from nltk.tokenize import word_tokenize
import re
from collections import Counter # elements are stored as dictionary keys
# and their counts are stored as dictionary values
import operator

# define a list to collect words
words = []

# load the file
with open(file, 'r') as f:
    for line in f:
        # remove empty lines
        if line.strip():
            # get word/punctuation tokens
            tokens = word_tokenize(line)
            # append words to the list
            for t in tokens:
                if re.match(r'\w', t[0]):
                    words.append(t.lower())

# make a dictionary of the mapping between words and their counts
word_count = dict(Counter(words))
# sort the (word, count) paris according to the count, in a decreasing order
word_count_sort = sorted(word_count.items(), key=operator.itemgetter(1), reverse=True)

print (word_count_sort)
