import nltk
nltk.data.show_cfg('grammars/book_grammars/grammar52.fcfg')

tokens = '谁 你 认为 猫 喜欢'.split()
from nltk import load_parser
cp = load_parser('grammars/book_grammars/grammar52.fcfg')
for tree in cp.parse(tokens):
        print(tree)
        tree.draw()
