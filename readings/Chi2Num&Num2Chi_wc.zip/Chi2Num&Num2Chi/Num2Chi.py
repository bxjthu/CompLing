import numpy as np
import re

digits = {"0": "零", "1": "一", "2": "二", "3": "三", "4": "四", "5": "五", "6": "六", "7": "七", "8": "八", "9": "九" }

def createT(num):
    assert len(num) == 4
    ret = digits[num[0]]
    if num[0] != "0": ret = ret + "千"
    if num[1] != "0": ret = ret + digits[num[1]] + "百"
    else: ret = ret + "零"
    if num[2] != "0": ret = ret + digits[num[2]] + "十"
    else:
        ret = ret + "零"
    if num[3] != "0": ret = ret + digits[num[3]]
    while (ret[-1] == "零"): ret = ret[:-1]
    return ret

def Num2Chi(num):
    if num == "0": return "零"
    sublist = []
    while (len(num)>4):
        sublist.append(num[-4:])
        num = num[:-4]
    if len(num) < 4: num = "0"*(4-len(num)) + num
    sublist.append(num)
    numl = len(sublist)
    retlist = []
    if sublist[0] != "0000": retlist.append(createT(sublist[0]))
    if numl > 1:
        if sublist[1] != "0000": retlist.append(createT(sublist[1])+"万")
        else: retlist.append("零")
        if numl > 2:
            for i in range(2, numl):
                if sublist[i] != '0000': retlist.append(createT(sublist[i])+"万"*(i-2)+"亿")
                else: retlist.append("零")
    retlist.reverse()
    ret = "".join(retlist)
    ret = re.sub(r"零(?=零)", "", ret)
    ret = re.sub(r"^零+", "", ret)
    ret = re.sub(r"零$", "", ret)
    if len(ret) > 2 and ret[-1] == "千" and ret[-3] == "万": ret = ret[:-1]
    if len(ret) > 2 and ret[-1] == "百" and ret[-3] == "千": ret = ret[:-1]
    if len(ret) > 2 and ret[-1] == "十" and ret[-3] == "百": ret = ret[:-1]
    ret = re.sub(r"(?<=[^十零])二(?=[百千万亿])", "两", ret)
    ret = re.sub(r"^二(?=[百千万亿])", "两", ret)
    if ret[0] == "一" and ret[1] == "十": ret = ret[1:]
    return ret

print(Num2Chi("5720"))
print(Num2Chi("352354252353"))
print(Num2Chi("34000000003003"))
print(Num2Chi("25353000100100014030034"))
print(Num2Chi("1000000000000"))
print(Num2Chi("100000000"))
print(Num2Chi("0"))

# test 二 两
print(Num2Chi("2"))
print(Num2Chi("20")) # 二十
print(Num2Chi("2000")) # 两千
print(Num2Chi("200")) # 两百
print(Num2Chi("120000000")) # 一亿两千万
print(Num2Chi("120000")) # 十二万
print(Num2Chi("1020000")) # 一百零二万

# test 十五 一十五
print(Num2Chi("15"))
print(Num2Chi("1115"))
print(Num2Chi("10152015"))

# test 五百八等等
print(Num2Chi("150")) # 一百五
print(Num2Chi("1600")) # 一千六
print(Num2Chi("18000")) # 一万八
print(Num2Chi("20000002222")) # 一千六
print(Num2Chi("1600")) # 一千六

