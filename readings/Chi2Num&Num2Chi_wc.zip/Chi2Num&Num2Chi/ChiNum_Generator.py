import numpy as np
import re
nonTerminal = ['F', 'T', 'H', 'P', 'B', 'D', 'd']
rules_nS = {
    'F': [
        ('F', 'T'),
        ('(?<=零)F', 'H'),
        ('^F', 'H'),
        ('(?<=[^零^])F', '零H'),
        ('(?<=万)F', 'D')
    ],
    'T': [
        ('T', 'D千'),
        ('T', 'D千P'),
        ('T', 'D千零B'),
        ('T', 'D千零D'),
        ('T$', 'D千D'),
        ],
    'H': [
        ('H', 'P'),
        ('H', 'B'),
        ('H', 'D')],
    'P': [
        ('P', 'D百'),
        ('P', 'D百B'),
        ('P', 'D百零D'),
        ('P$', 'D百D')],
    'B': [
        ('(?<=[^^])B', 'D十'),
        ('(?<=[^^])B', 'D十D'),
        ('^B', '十'),
        ('^B', 'd十'),
        ('^B', 'd十D'),
        ('^B', '十D')],
    'D': [
        ('D', '一'),
        ('D', 'd')],
    'd': [
        ('d', '三'),
        ('d', '四'),
        ('d', '五'),
        ('d', '六'),
        ('d', '七'),
        ('d', '八'),
        ('d', '九'),
        ('(?<=[^十零])d(?=[百千万亿])', '两'),
        ('^d(?=[百千万亿])', '两'),
        ('d(?=[百千万亿])', "二")
    ]

}


def generate(rules_nS, nonTerminal, max_gap, ):
    ret = "S"

    # rule for S
    while True:
        rand = np.random.randint(0, 10)
        if rand > 6 and ret != 'S':
            ret = ret[1:]
            break

        nIncrease = np.random.randint(0, max_gap+1)
        if ret == 'S':
            rand = np.random.randint(0,10)
            if rand < 8: ret = 'SF'
            elif rand == 8: ret = 'SF万'
            else: ret = 'SF' + '万'*nIncrease + '亿'
        elif len(ret) == 2:
            rand = np.random.randint(0,10)
            if rand < 7: ret = 'SF万F'
            else: ret = 'SF' + '万'*nIncrease + '亿零F'
        elif ret[1:4] == 'F万F':
            rand = np.random.randint(0, 10)
            if rand < 7: ret = 'SF亿' + ret[1:]
            else: ret = 'SF' + '万'*(1+nIncrease) + '亿零' + ret[1:]
        else:
            rand = np.random.randint(0, 10)
            span = re.search(r'SF万*', ret)
            N = span.end() - 2
            if rand < 5: ret = 'SF' + '万'*(N+1) + '亿' + ret[1:]
            else: ret = 'SF' + '万'*(N+2+nIncrease) + '亿零' + ret[1:]

    for nT in nonTerminal:
        opList = rules_nS[nT]
        lopList = len(opList)
        finish = False
        while not finish:
            rand = np.random.randint(0, lopList)
            ret = re.sub(opList[rand][0], opList[rand][1], ret, 1)
            if nT not in ret: finish = True
    return ret

# test
for i in range(10):
    print(generate(rules_nS, nonTerminal, 2))


