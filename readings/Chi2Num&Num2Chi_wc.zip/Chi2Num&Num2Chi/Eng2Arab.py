def read(s):
    # form numbers between items in ["trillion", "billion", "million", "thousand"]
    def form(start, end):
        t = 0
        if num[start] in single and start+1 < end and num[start+1] == "hundred":
            t = single[num[start]] * 100
            start += 2
        for item in num[start:end]:
            if item == 'and': continue
            if item in single: t += single[item]
            elif item in tens: t += tens[item]
            elif item in ty: t += ty[item]
            else:
                temp = item.split("-")
                t += ty[temp[0]] + single[temp[1]]
        result.append(t)
    
    # English to number dicts
    cut = ["trillion", "billion", "million", "thousand"]
    single = {"one": 1, "two":2, "three":3, "four":4, "five":5, "six":6, "seven":7, "eight":8, "nine":9}
    tens = {"eleven": 11, "twelve":12, "thirteen": 13, "fourteen":14, "fifteen":15, "sixteen":16, "seventeen":17, "eighteen":18, "ninteen":19, "ten":10}
    ty = {"twenty": 20, "thirty":30, "forty":40, "fifty":50, "sixty": 60, "seventy": 70,"eighty": 80, "ninty":90}
    
    # initialization
    num = s.split()
    start = 0
    result = []
    
    # determine the first used 
    count = 0
    for item in cut:
        if item not in num:
            count += 1
        else: break
    cut = cut[count:]
    
    # if there is no "thousand" in the string but "million", we have to add a zero for the "thousand" part.
    for i in range(0, len(cut)):
        if cut[i] in num:
            end = num.index(cut[i])
            form(start, end)
        else:
            end = start - 1
            result.append(0)
        start = end+1
    if start < len(num): form(start,len(num))
    else: result.append(0)
    
    # print out the result
    for i in range(0, len(result)):
        if i != 0 and result[i] < 100: print(0, end = "")
        if i != 0 and result[i] < 10: print(0, end = "")
        print(result[i],end = "")
    print()

# For testing
read("one hundred thousand five hundred and ten")
read(s = "thirty-five thousand")
read("twelve billion five hundred and thirty-two million seven hundred and one thousand five hundred and thirty-two")
read("one trillion and ten")
read("two trillion five hundred and twelve thousand")



