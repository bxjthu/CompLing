import re

params = {"一":1, "二":2, "两":2, "三":3, "四":4, "五":5, "六":6, "七":7, "八":8, "九":9}
posits = ["千", "百", "十"]


def form(string):
    if string == "零": return '0'
    if len(string) == 1: return [0,0,0, params[string]]
    if string[0] == "十": string = "一" + string

    ret = [0,0,0,0]
    for index, posit in enumerate(posits):
        if posit in string:
            ret[index] = params[re.findall('(.)'+posit, string)[0]]
    if (string[-1] in params) and (string[-2] == "零" or string[-2] == "十"): ret[-1] = params[string[-1]]
    elif string[-1] in params: ret[posits.index(string[-2])+1] = params[string[-1]]

    return ret


def chi2num(num_raw):

    cut_raw = re.findall("万*亿|万", num_raw)
    if cut_raw: cut_max = cut_raw[0]
    else: return form(num_raw)
    num = []
    for cut in cut_raw:
        span = re.search(cut, num_raw).span()
        num.append(num_raw[:span[0]])
        num.append(cut)
        num_raw = num_raw[span[1]:]
    if num_raw: num.append(num_raw)
    cuts = [cut_max[i:] for i in range(len(cut_max))]
    if cut_max != "万": cuts.append("万")

    result = []
    for cut in cuts:
        if cut in num:
            index = num.index(cut) - 1
            result.append(form(num[index]))
        else:
            result.append([0,0,0,0])
    if num[-1] != cut_raw[-1]: result.append(form(num[-1]))
    else: result.append([0,0,0,0])
    if (num[-1] in params.keys()) and (len(num) > 1): result[-1] = [params[num[-1]], 0,0,0]
    ret = ''.join([str(digit) for cut in result for digit in cut])
    for _ in range(3):
        if ret[0] == '0': ret = ret[1:]

    return ret

print(chi2num("二十万万万亿零三千五百万亿零三亿五千两百三十万零八百三十二"))
print(chi2num("二十万万万亿零三十二"))
print(chi2num("二十万八"))
print(chi2num("五亿"))
print(chi2num("五十万"))
print(chi2num("九十万万亿零八亿"))
print(chi2num("三千"))
print(chi2num("三千二百"))
print(chi2num("三千九"))
print(chi2num("零"))